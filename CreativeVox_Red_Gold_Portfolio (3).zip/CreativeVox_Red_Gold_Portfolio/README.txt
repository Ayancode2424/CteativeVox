CREATIVEVOX MEDIA — RED + GOLD PORTFOLIO

FILES
- index.html  : website structure and content
- styles.css  : responsive dark, gold and red visual design
- script.js   : mobile navigation and scroll reveal effects

RUN LOCALLY
1. Extract the ZIP.
2. Open the folder in Visual Studio Code.
3. Open index.html in your browser, or use the VS Code Live Server extension.

PUBLISH ONLINE FOR A SHAREABLE LINK
1. Create a GitHub repository.
2. Upload index.html, styles.css and script.js to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
5. After GitHub Pages finishes deploying, it will show your live website URL.

CONTENT NOTE
The reference's business details and section topics are retained, with a new red/gold visual style. The portfolio tiles are illustrative concept artwork, not real client case studies. Replace contact/team details if you are publishing for a different business.
